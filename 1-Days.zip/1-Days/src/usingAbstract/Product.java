package usingAbstract;

public abstract class Product {
	
	int pid = 0;
	
	abstract public void productID( int pid );
	
	public String productTitle() {
		if (pid == 5) {
			return "Buzdolabı";
		}else {
			return "Ürün Yok";
		}
	}

}

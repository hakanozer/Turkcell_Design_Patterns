package usingAbstract;

public class ProductUtil extends Product {

	@Override
	public void productID(int pid) {
		//this.pid = pid;
		super.pid = pid;
	}

}

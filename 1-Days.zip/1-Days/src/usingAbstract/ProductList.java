package usingAbstract;

import java.util.ArrayList;
import java.util.List;

public class ProductList extends ProductUtil {
	
	int[] ids = new int[0];
	public ProductList( String name,  int... ids ) {
		this.ids = ids;
	}
	
	public List<String> fncProductList() {
		List<String> ls = new ArrayList<String>();
		
		for (int id : ids) {
			productID(id);
			ls.add(productTitle());
		}
		
		return ls;
	}

}

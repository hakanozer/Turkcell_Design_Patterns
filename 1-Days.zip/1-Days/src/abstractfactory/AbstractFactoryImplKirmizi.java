package abstractfactory;

public class AbstractFactoryImplKirmizi implements AbstractFactory {

	@Override
	public Elma getElma() {
		return new KirmiziElma();
	}

	@Override
	public Biber getBiber() {
		return new KirmiziBiber();
	}

}

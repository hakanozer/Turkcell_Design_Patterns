package abstractfactory;

public class YesilElma implements Elma {

	@Override
	public String getType() {
		return "Yeşil Elma";
	}

}

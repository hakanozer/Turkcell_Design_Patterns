package abstractfactory;

public interface Elma {
	
	public String getType();

}

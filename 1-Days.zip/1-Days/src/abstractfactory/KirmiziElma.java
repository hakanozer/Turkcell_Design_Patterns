package abstractfactory;

public class KirmiziElma implements Elma {

	@Override
	public String getType() {
		return "Kırmızı Elma";
	}

}

package abstractfactory;

public interface AbstractFactory {
	
	Elma getElma();
	
	Biber getBiber();

}

package abstractfactory;

public class YesilBiber implements Biber {

	@Override
	public String getType() {
		return "Yeşil Biber";
	}

	
}

package abstractfactory;

public class KirmiziBiber implements Biber {

	@Override
	public String getType() {
		return "Kırmızı Biber";
	}

	
}

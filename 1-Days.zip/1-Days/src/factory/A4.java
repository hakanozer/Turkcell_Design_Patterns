package factory;

public class A4 extends Araba {

	public A4(final int beygirgubu) {
		super("Audi", "A4", beygirgubu);
	}

}

package factory;

import java.util.ArrayList;

public abstract class ArabaFabrika {
	
	public ArabaFabrika() {
		createAuto();
	}
	
	public abstract void createAuto();

	private ArrayList<Araba> arabaListesi = new ArrayList<>();

	public ArrayList<Araba> getArabaListesi() {
		return arabaListesi;
	}

	public void setArabaListesi(ArrayList<Araba> arabaListesi) {
		this.arabaListesi = arabaListesi;
	}
	
	
}

package factory;

public class BwmFabrika extends ArabaFabrika {

	@Override
	public void createAuto() {
		getArabaListesi().add(new Z4(170));
	}

}

package factory;

public class Test {

	public static void main(String[] args) {
		
		ArabaFabrika bwm = new BwmFabrika();
		ArabaFabrika audi = new AudiFabrika();
		
		carList(bwm);
		carList(audi);

	}
	
	public static void carList( ArabaFabrika fbr ) {
		for(Araba item : fbr.getArabaListesi()) {
			System.out.println("Marka : " + item.getMarka() + " Model : " + item.getModel() + " BeygirGücü " + item.getBeygirgubu());
		}
	}
	

}

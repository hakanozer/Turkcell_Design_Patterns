package factory;

public class Z4 extends Araba {

	public Z4( final int beygirgubu ) {
		super("BMW", "Z4", beygirgubu);
	}

}

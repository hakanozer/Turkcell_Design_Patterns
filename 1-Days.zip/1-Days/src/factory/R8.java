package factory;

public class R8 extends Araba {

	public R8(final int beygirgubu) {
		super("Audi", "R8", beygirgubu);
	}

}

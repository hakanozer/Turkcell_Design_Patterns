package factory;

public abstract class Araba {
	
	private String marka = null;
	private String model = null;
	private int beygirgubu = 0;
	

	public Araba(String marka, String model, int beygirgubu) {
		super();
		this.marka = marka;
		this.model = model;
		this.beygirgubu = beygirgubu;
	}
	
	public String getMarka() {
		return marka;
	}
	public void setMarka(String marka) {
		this.marka = marka;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getBeygirgubu() {
		return beygirgubu;
	}
	public void setBeygirgubu(int beygirgubu) {
		this.beygirgubu = beygirgubu;
	}
	
	
	

}

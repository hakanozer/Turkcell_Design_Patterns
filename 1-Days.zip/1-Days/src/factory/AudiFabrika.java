package factory;

public class AudiFabrika extends ArabaFabrika {

	@Override
	public void createAuto() {
		getArabaListesi().add(new A4(140));
		getArabaListesi().add(new R8(300));
	}

}

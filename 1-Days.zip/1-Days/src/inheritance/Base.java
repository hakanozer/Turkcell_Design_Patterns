package inheritance;

public class Base  {
	
	public Base() {
		System.out.println("Base Call");
	}
	
	public Base( String data ) {
		System.out.println("Base Call data " + data);
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
			
		}
	}

	public void sum( int a, int b ) {
		int sm = a + b;
		System.out.println(" Base sum = " + sm);
	}
	
	final public void read() {
		System.out.println("Read Call");
	}
	
	static public void fncRed() {
		System.out.println("Red call");
	}
	
}

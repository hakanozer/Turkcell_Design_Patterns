package inheritance;

public class B extends Base {
	
	public B() {
		super("B pull data");
		System.out.println("B Call");
	}
	
	@Override
	public void sum(int a, int b) {
		int carp = a * b;
		System.out.println(" B carp = " + carp);
	}
	
}

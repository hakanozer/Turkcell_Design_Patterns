package inheritance;

import usingInterface.IUser;

public class A extends Base implements IUser {
	
	public A() {
		super("A pull data");
		System.out.println("A Call");
	}

	@Override
	public void sum(int a, int b) {
		int minus = a - b;
		System.out.println(" A minus = " + minus);
	}
	
	public void write() {
		sum(40, 70);
		super.sum(40, 70);
		fncRed();
		read();
		System.out.println("a write call");
	}

	@Override
	public String userPhotoPath(int uid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String userName(int uid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte userAge(int uid) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
}

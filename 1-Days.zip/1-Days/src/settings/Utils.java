package settings;

public class Utils {
	
	int number = 0;
	int i = 0;
	public Utils() {
		super();
		System.out.println("Utils call");
		//Utils ut = new Utils();
		//i++;
		//ut = null;
	}
	
	public Utils( int number ) {
		this.number = number;
		write();
	}
	
	
	public void sum( int a, int b ) {
		int sm = a + b + number;
		System.out.println("Sum : " + sm);
	}
	
	
	public void write() {
		System.out.println("Write Call");
	}
	

	
}

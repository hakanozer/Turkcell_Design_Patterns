package usingInterface;

public interface IUser extends IPhoto {

	 String userName(int uid);
	 byte userAge(int uid);
	
	 default public int userClass(int uid) {
		 return 3;
	 }
	 int number = 10;
	 
	
}

package usingInterface;

public class User implements IUser, IProfile {

	@Override
	public String userName(int uid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte userAge(int uid) {
		System.out.println("Number : " + number);
		userClass(uid);
		return 0;
	}

	@Override
	public boolean userPasswordChance(int uid, String oldPass) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String userPhotoPath(int uid) {
		// TODO Auto-generated method stub
		return null;
	}

	

	

}

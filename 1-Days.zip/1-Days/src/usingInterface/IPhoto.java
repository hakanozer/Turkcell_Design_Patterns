package usingInterface;

public interface IPhoto {

	String userPhotoPath(int uid);
	
}

package usingInterface;

public interface IProfile {
	
	boolean userPasswordChance(int uid, String oldPass);
	
}

package factoryMethod;

public interface Document {

	String getDocumentype();
	
}

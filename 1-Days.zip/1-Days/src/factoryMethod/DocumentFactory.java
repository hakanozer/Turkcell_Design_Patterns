package factoryMethod;

public class DocumentFactory {

	public static Document crerateDocument( final String type ) {
		if ( type.equalsIgnoreCase("pdf") ) {
			return new Pdf();
		}else if ( type.equalsIgnoreCase("word") ) {
			return new Word();
		}else {
			throw new RuntimeException("Böyle bir tür yok!");
		}
	}
	
	
}

package factoryMethod;

public class Pdf implements Document {

	@Override
	public String getDocumentype() {
		return "PDF";
	}

	
	
}

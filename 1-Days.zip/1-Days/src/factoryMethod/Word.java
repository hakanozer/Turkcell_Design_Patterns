package factoryMethod;

public class Word implements Document {

	@Override
	public String getDocumentype() {
		return "WORD";
	}

}

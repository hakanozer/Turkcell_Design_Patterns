package factoryMethod;

public class Test {

	public static void main(String[] args) {
		
		Document document = DocumentFactory.crerateDocument("pdf");
		System.out.println(document.getDocumentype());
		
		document = DocumentFactory.crerateDocument("word");
		System.out.println(document.getDocumentype());

	}

}

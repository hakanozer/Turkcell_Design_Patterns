package appPack;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import inheritance.A;
import inheritance.B;
import inheritance.Base;
import settings.Utils;
import usingAbstract.ProductList;
import usingAbstract.ProductUtil;
import usingInterface.IPhoto;
import usingInterface.IUser;
import usingInterface.User;

public class MainApp {

	public static void main(String[] args) {

		Utils ut = new Utils();
		ut.sum(40, 50);
		
		Utils uts = new Utils(100);
		uts.sum(40, 50);
		
		Scanner read = new Scanner(System.in);
		String data = read.nextLine();
		System.out.println(data);
		
		User us = new User();
		us.userAge(10);
		
		IUser us1 = new User();
		us1.userAge(10);
		
		IPhoto us2 = new User();
		us2.userPhotoPath(10);
		
		
		IUser us3 = new IUser() {
			
			@Override
			public String userPhotoPath(int uid) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public String userName(int uid) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public byte userAge(int uid) {
				// TODO Auto-generated method stub
				return 0;
			}
		};
		
		ProductList ls = new ProductList("", 5,6,7,8,5,5,9);
		List<String> list = ls.fncProductList();
		for (String item : list) {
			System.out.println("Produt Title : " + item);
		}
		
		Base base = new Base();
		A a = new A();
		B b = new B();
		
		fncCall(base);
		fncCall(a);
		fncCall(b);
		
		
		// Base bsa = new A();
		IUser iua = new A();

	}
	
	
	public static void fncCall ( Base base ) {
		if (base instanceof A) {
			A aa = (A) base;
			aa.write();
		}
		base.sum(50, 30);
	}
	

}

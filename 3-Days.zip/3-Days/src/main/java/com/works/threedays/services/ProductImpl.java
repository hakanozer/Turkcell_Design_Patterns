package com.works.threedays.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.works.threedays.models.Product;
import com.works.threedays.repostories.ProductRepostory;

@Service
public class ProductImpl implements IProduct {

	@Autowired ProductRepostory productRepostory;
	
	@Override
	public List<Product> allProduct(int pid) {
		if (pid == 1) {
			return null;
		}
		return productRepostory.findAll();
	}
	
	

}

package com.works.threedays.channel;

public class OrderWorker implements Runnable {

	@Override
	public void run() {
		
		try {
			
			while(true) {
				OrderMessage message = MessageChannel.message();
				long time = System.currentTimeMillis();
				System.out.println(" Time : " + time + " OrderID : " + message.getOrder().getId() );
				Thread.sleep(1000);
			}
			
			
		} catch (Exception e) {
			System.err.println("OrderWorker Error : " + e);
		}
		
	}

}

package com.works.threedays.util;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

@Configuration(value = "encodingFilter")
@Order(1)
public class CharacterEncodingFilter implements Filter {
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		System.out.println("init call");
	}
	

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		
		req.setCharacterEncoding("UTF8");
		res.setCharacterEncoding("UTF8");
		
		System.out.println("doFilter Call");
		
		 Map<String, String[]> map = req.getParameterMap();
		 Set<String> keys = map.keySet();
		 for (String key : keys) {
			String val = map.get(key)[0];
			System.out.println(key + " val : " + val);
			if (val.contains("<script>")) {
				System.exit(0);
			}
		}
		
		chain.doFilter(req, res);
	}
	
	
	@Override
	public void destroy() {
		for (int i = 0; i < 10; i++) {
			try {
				Thread.sleep(1000);
				System.out.println("Down Test");
			} catch (Exception e) {
				System.err.println("Error : " + e);
			}
		}
		System.out.println("Server Down");
	}
	

}

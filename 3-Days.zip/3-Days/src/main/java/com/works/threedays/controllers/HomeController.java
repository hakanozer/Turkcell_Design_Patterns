package com.works.threedays.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.works.threedays.models.Product;
import com.works.threedays.repostories.ProductRepostory;
import com.works.threedays.services.ProductImpl;

@Controller
public class HomeController {
	
	@Autowired ProductRepostory productRepostory;
	@Autowired ProductImpl productImpl;
	
	List<String> ls = new ArrayList<>();
	
	
	public HomeController() {
		System.out.println("HomeController call");
		dataResult();
	}
	
	@PostConstruct
	public void dataResult() {
		for (int i = 0; i < 10; i++) {
			ls.add("Ali - " + i);
		}
	}
	
	
	@GetMapping({ "", "/" })
	public String home( Model model, Random rd ) {
		model.addAttribute("name", "Zehra Bilsin");
		model.addAttribute("rd", rd.nextInt(100));
		model.addAttribute("ls", ls);
		
		List<Product> pls = productRepostory.priceResult(1000);
		model.addAttribute("pls", pls);
		
		productImpl.allProduct(10);
		
		return "home";
	}
	
	
	@PostMapping("/productInsert")
	public String productInsert( Product pr ) {
		productRepostory.saveAndFlush(pr);
		return "redirect:/";
	}
	
	
	@PostMapping("/productInsertService")
	public String productInsertService( @RequestBody Product pr ) {
		productRepostory.saveAndFlush(pr);
		return "redirect:/";
	}
	
	

}

package com.works.threedays.channel;

import java.util.ArrayList;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		
		OrderWorker orderWorker = new OrderWorker();
		Thread th1 = new Thread(orderWorker);
		th1.start();
		
		Order order = new Order();
		order.setCustomer(new Customer());
		order.setId(100);
		
		List<Item> ls = new ArrayList<Item>();
		ls.add(new Item());
		order.setItems(ls);
		
		
		OrderService orderService = new OrderService();
		orderService.newOrder(order);
		orderService.newOrder(order);
		orderService.newOrder(order);
		orderService.newOrder(order);
		orderService.newOrder(order);
		
		
		
	}
	
	
}

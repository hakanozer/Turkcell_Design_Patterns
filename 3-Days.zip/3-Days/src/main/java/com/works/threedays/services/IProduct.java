package com.works.threedays.services;

import java.util.List;

import com.works.threedays.models.Product;

public interface IProduct {

	List<Product> allProduct( int pid );
	
}

package com.works.threedays.channel;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class MessageChannel {

	private static BlockingQueue<OrderMessage> orderQue = new ArrayBlockingQueue<>(10);
	
	public static void put( OrderMessage message ) {
		orderQue.add(message);
	}
	
	public static OrderMessage message() throws InterruptedException  {
		return orderQue.take();
	}
	
	
	
	
}

package objectpool;

public class Connection {

}

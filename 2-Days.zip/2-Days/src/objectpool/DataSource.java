package objectpool;

import java.nio.channels.NoConnectionPendingException;
import java.util.ArrayList;
import java.util.List;

public class DataSource {

	static DataSource intance = new DataSource();
	List<Connection> pool = new ArrayList<Connection>();
	
	public DataSource() {
		init();
	}
	
	public void init() {
		for (int i = 0; i < 4; i++) {
			pool.add(new Connection());
		}
	}
	
	static Connection getConnection() {
		if ( intance.pool.size() == 0 ) {
			throw new NoConnectionPendingException();
		}
		
		Connection con = intance.pool.get(0);
		intance.pool.remove(0);
		
		System.out.println(con);
		
		return con;
		
	}
	
	
	static void relase( Connection conn ) {
		if ( conn != null) {
			intance.pool.add(conn);
		}
	}
	
}

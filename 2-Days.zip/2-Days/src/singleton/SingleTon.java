package singleton;

public class SingleTon {
	
	
	private static SingleTon instance = null;
	
	private static Object lock = new Object();
	
	private SingleTon() {
		System.out.println("SingleTon init()");
	}
	
	public static SingleTon instance() {
		if (instance == null) {
			synchronized (lock) {
				if (instance == null) {
					instance = new SingleTon();
				}
			}
		}
		return instance;
	}
	
	
	public void printThis() {
		System.out.println(this);
	}
	

}

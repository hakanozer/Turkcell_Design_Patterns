package builder;

public class Test {

	public static void main(String[] args) {
		
		SiparisManager manager = new SiparisManager(CEnum.audi);
		manager.createOrder("Audi", "A5", "Siyah", 140);
		call(manager);
		
		manager = new SiparisManager(CEnum.ford);
		manager.createOrder("Ford", "Focus", "Beyaz", 100);
		call(manager);
		
	}
	
	public static void call(SiparisManager manager) {
		manager.printOrder();
		if ( manager.builder instanceof AudiSiparisBuilder ) {
			AudiSiparisBuilder audiSiparisBuilder = (AudiSiparisBuilder) manager.builder ;
			audiSiparisBuilder.audiClass();
		}
	}
	
	
}

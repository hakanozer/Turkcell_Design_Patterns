package builder;

public enum CEnum {

	audi, ford;
	
}

package builder;

public class SiparisManager {

	public SiparisBuilder builder;
	
	public SiparisManager( CEnum cEnum ) {
		switch (cEnum) {
		case audi:
			this.builder = new AudiSiparisBuilder(); 
			break;
		case ford:
			this.builder = new FordSiparisBuilder();
			break;
		default:
			break;
		}
	}
	
	
	public Araba createOrder( String marka, String model, String renk, int beygirgucu ) {
		
		builder.setBeygirgucu(beygirgucu);
		builder.setMarka(marka);
		builder.setModel(model);
		builder.setRenk(renk);
		
		return builder.getAraba();
		
	}
	
	
	public void printOrder() {
		System.out.println("Marka : " + builder.getAraba().getMarka());
		System.out.println("Model : " + builder.getAraba().getModel());
		System.out.println("Renk : " + builder.getAraba().getRenk());
		System.out.println("Beygir Gücü : " + builder.getAraba().getBeygirgucu());
	}
	
	
	
}

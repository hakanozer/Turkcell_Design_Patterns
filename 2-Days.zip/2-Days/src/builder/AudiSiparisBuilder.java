package builder;

public class AudiSiparisBuilder extends SiparisBuilder {
	
	public AudiSiparisBuilder() {
		System.out.println("AudiSiparisBuilder call");
	}

	@Override
	public void setMarka(String marka) {
		getAraba().setMarka(new Marka(marka));
	}

	@Override
	public void setModel(String model) {
		getAraba().setModel(new Model(model));	
	}

	@Override
	public void setRenk(String renk) {
		getAraba().setRenk(renk);
		
	}

	@Override
	public void setBeygirgucu(int beygirgucu) {
		getAraba().setBeygirgucu(beygirgucu);
		
	}
	
	public void audiClass() {
		System.out.println("audiClass call");
	}
	

}

package prototype;

public class SahisAdres extends AdresPrototype {
	
	private String ad;
	private String soyadi;
	
	public SahisAdres(String sokak, String no, String semt, String sehir, String ad, String soyadi) {
		setSokak(sokak);
		setNo(no);
		setSemt(semt);
		setSehir(sehir);
		setAd(ad);
		setSoyadi(soyadi);
	}

	public String getAd() {
		return ad;
	}

	public void setAd(String ad) {
		this.ad = ad;
	}

	public String getSoyadi() {
		return soyadi;
	}

	public void setSoyadi(String soyadi) {
		this.soyadi = soyadi;
	}
	
	
	
	
}

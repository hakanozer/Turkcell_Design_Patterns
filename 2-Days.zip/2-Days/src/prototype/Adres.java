package prototype;

public class Adres extends AdresPrototype {

	public Adres(String sokak, String no, String semt, String sehir) {
		setSokak(sokak);
		setNo(no);
		setSemt(semt);
		setSehir(sehir);
	}
	
}

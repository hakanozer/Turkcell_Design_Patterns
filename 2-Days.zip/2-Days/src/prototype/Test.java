package prototype;

public class Test {

	public static void main(String[] args) throws CloneNotSupportedException {
		
		
		final Adres adres1 = new Adres("1.sok", "12", "Beşiktaş", "İstanbul");
		call(adres1);
		
		final Adres adres2 = (Adres) adres1.clone();
		//adres2.setSokak("2.sok");
		//adres2.setNo("13");
		adres2.setSemt("Zeytinburnu");
		//adres2.setSehir("İstanbul");
		call(adres2);

	}
	
	public static void call(AdresPrototype adresPrototype) {
		adresPrototype.printAdres();
	}
	

}

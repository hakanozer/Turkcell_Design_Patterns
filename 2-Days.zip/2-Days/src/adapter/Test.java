package adapter;

public class Test {

	public static void main(String[] args) {
		
		IKullanici kullanici = new AdapterSinif();
		kullanici.write();
		
	}

}

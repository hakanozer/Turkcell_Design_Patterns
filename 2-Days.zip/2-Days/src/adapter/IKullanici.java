package adapter;

public interface IKullanici {
	
	void write();

}

package adapter;

public class AdapterSinif extends AdapteEdilenSinif implements IKullanici {

	@Override
	public void write() {
		read();
	}

}

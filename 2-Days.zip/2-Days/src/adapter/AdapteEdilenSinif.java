package adapter;

public class AdapteEdilenSinif {

	public void read() {
		System.out.println("read call");
	}
	
}

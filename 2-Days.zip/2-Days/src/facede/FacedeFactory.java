package facede;

public class FacedeFactory {
	
	private static FacedeFactory instance = new FacedeFactory();
	
	public static FacedeFactory instance() {
		return instance;
	}
	
	public KomponentFacede getFacede() {
		return new FacedeImpl();
	}

}

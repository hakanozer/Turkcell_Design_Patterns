package facede;


public class Test {

	public static void main(String[] args) {
		
		FacedeFactory.instance().getFacede().action();

	}

}

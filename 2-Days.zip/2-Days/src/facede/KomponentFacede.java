package facede;

public interface KomponentFacede {

	void action();
	
}

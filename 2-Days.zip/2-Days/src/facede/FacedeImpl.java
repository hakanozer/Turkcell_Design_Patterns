package facede;

public class FacedeImpl implements KomponentFacede {

	@Override
	public void action() {
		new Util().read();
	}

}

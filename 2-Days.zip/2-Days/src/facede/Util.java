package facede;

public class Util {
	
	public void read() {
		System.out.println("read Call");
	}
	
}

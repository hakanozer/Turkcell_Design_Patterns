package bridge;

public class UretimImpl2 implements Uretim {

	final Fabrika2 fb2 = new Fabrika2();
	
	@Override
	public void produceDefter() {
		fb2.produceCizgiliDefter();
	}

	@Override
	public void produceKalem() {
		fb2.produceDolmaKalem();
	}

}

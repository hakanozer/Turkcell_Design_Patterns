package bridge;

public class Test {

	public static void main(String[] args) {
		
		Envanter defter = new Defter(new UretimImpl1());
		defter.produce();

		defter = new Defter(new UretimImpl2());
		defter.produce();
		
		
		
		Envanter kalem = new Kalem(new UretimImpl1());
		kalem.produce();
		
		kalem = new Kalem(new UretimImpl2());
		kalem.produce();

	}

}

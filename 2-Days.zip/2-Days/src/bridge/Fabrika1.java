package bridge;

public class Fabrika1 {
	
	public void produceTukenmezKalem() {
		System.out.println(" Fabrika1 : Tukenmez Kalem imal etti");
	}
	
	public void produceKareliDefter() {
		System.out.println(" Fabrika1 : Kareli Defter imal etti");
	}

}

package bridge;

public interface Uretim {

	void produceDefter();
	void produceKalem();
	
}

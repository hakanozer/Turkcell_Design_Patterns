package bridge;

public class UretimImpl1 implements Uretim {
	
	final Fabrika1 fb1 = new Fabrika1();

	@Override
	public void produceDefter() {
		fb1.produceKareliDefter();
	}

	@Override
	public void produceKalem() {
		fb1.produceTukenmezKalem();
	}
	
	

}

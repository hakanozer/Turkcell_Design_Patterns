package bridge;

public class Fabrika2 {

	public void produceDolmaKalem() {
		System.out.println(" Fabrika2 : Dolma Kalem imal etti");
	}
	
	public void produceCizgiliDefter() {
		System.out.println(" Fabrika2 : Çizgili Defter imal etti");
	}
	
	
}
